import 'package:flutter/material.dart';

class ProfileArea extends StatelessWidget {

  final Function ()? onT;
  final String avatar;
  final String name;

  const ProfileArea({
    super.key, this.onT, required this.avatar, required this.name,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, "/profile");
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color.fromARGB(255, 255, 253, 108),
              ),
              child: Container(
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color.fromARGB(255, 255, 255, 255),
              ),
                child: CircleAvatar(
                  backgroundImage: AssetImage("assets/images/the-weeknd.jpeg"),
                  radius: 40,
                  ),
              ),
            ),
            SizedBox(width: 8,),
            Text("Berke Cem"),
          ],
        ),
      ),
    );
  }
}

