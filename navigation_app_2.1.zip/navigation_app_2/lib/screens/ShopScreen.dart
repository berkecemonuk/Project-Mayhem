import 'package:flutter/material.dart';
import '../widgets/DrawerItem.dart';
import '../widgets/ProfileArea.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Shop"),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            ProfileArea(
              avatar: 'assets/images/the-weeknd.jpeg',
              name: 'Berke',
              onT: () {
                Navigator.pushNamed(context, "/profile");
              },
            ),
            Expanded(
              child: Column(
                children: [
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "Home",
                    icon: Icon(Icons.home_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/home");
                    },
                  ),
                  DrawerItem(
                    title: "Explore",
                    icon: Icon(Icons.explore_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/explore");
                    },
                  ),
                  DrawerItem(
                    title: "Shop",
                    icon: Icon(Icons.shop_2_outlined, size: 25),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "About us",
                    icon: Icon(Icons.info_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/aboutus");
                    },
                  ),
                  DrawerItem(
                    title: "Settings",
                    icon: Icon(Icons.settings_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/settings");
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    icon: Icon(Icons.logout_outlined),
                    onTap: () {
                      Navigator.pushNamedAndRemoveUntil(context, "/welcome", (route) => false);
                    },
                    title: "Logout",
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Version 0.7.7",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 10,
              ),
            ),
            SizedBox(height: 5),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: 7,
        itemBuilder: (context, index) {
          return ProductCard(productName: 'T-shirt $index', price: '\$1', imagePath: 'assets/images/product_$index.jpeg');
        },
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final String productName;
  final String price;
  final String imagePath;

  const ProductCard({
    Key? key,
    required this.productName,
    required this.price,
    required this.imagePath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Image.asset(
            imagePath,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  productName,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 8),
                Text(
                  'Price: $price',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.green,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    
                  },
                  child: Text('Make Offer'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}