import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key});

  GoToLoginScreen() {}

  GoToRegisterScreen() {
    print("register tiklandi");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Welcome to Project Mayhem",
          style: TextStyle(color: Colors.black),
          ),
      backgroundColor: const Color.fromARGB(255, 255, 253, 108),
),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Welcome to Project Mayhem", style: TextStyle(fontSize: 30),),
            SizedBox(height: 25),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, "/login"),
                  child: Row(
                    children: [
                      Icon(Icons.login_outlined),
                      SizedBox(width: 10),
                      Text("login")
                    ],
                  ),
                ),
                SizedBox(width: 15),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, "/register"),
                  child: Row(
                    children: [
                      Icon(Icons.app_registration),
                      SizedBox(width: 10),
                      Text("register")
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
