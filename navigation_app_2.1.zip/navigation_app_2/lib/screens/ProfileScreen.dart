import 'package:flutter/material.dart';
import 'package:navigation_app_2/widgets/DrawerItem.dart';
import 'package:navigation_app_2/widgets/ProfileArea.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            SizedBox(height: 20),
            ProfileArea(
              avatar: "assets/images/the-weeknd.jpeg",
              name: "Berke Cem",
            ),
            Divider(),
            DrawerItem(
              title: "email: berkecemonuk04@gmail.com",
              icon: Icon(Icons.email_outlined),
              onTap: () {}
              ),
              Divider(),
              DrawerItem(
              title: "Phone number:0 777 777 77 77",
              icon: Icon(Icons.phone_outlined),
              onTap: () {}
              ),
              Divider(),
              DrawerItem(
              title: "Sockets and Network Specialist",
              icon: Icon(Icons.topic_outlined),
              onTap: () {}
              ),
              Divider(),
            SizedBox(height: 25,),
            ElevatedButton(
              onPressed: () {
                if(Navigator.canPop(context)){
                Navigator.pop(context);
                }
              },
              child: Text("Go back"),
            ),
          ],
        ),
      ),
    );
  }
}
