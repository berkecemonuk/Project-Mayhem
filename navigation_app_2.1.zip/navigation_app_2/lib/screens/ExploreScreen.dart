import 'package:flutter/material.dart';
import '../widgets/DrawerItem.dart';
import '../widgets/ProfileArea.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Explore"),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            ProfileArea(
              avatar: 'assets/images/the-weeknd.jpeg',
              name: 'Berke',
              onT: () {
                Navigator.pushNamed(context, "/profile");
              },
            ),
            Expanded(
              child: Column(
                children: [
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "Home",
                    icon: Icon(Icons.home_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/home");
                    },
                  ),
                  DrawerItem(
                    title: "Explore",
                    icon: Icon(Icons.explore_outlined, size: 25),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  DrawerItem(
                    title: "Shop",
                    icon: Icon(Icons.shop_2_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/shop");
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    title: "About us",
                    icon: Icon(Icons.info_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/aboutus");
                    },
                  ),
                  DrawerItem(
                    title: "Settings",
                    icon: Icon(Icons.settings_outlined, size: 25),
                    onTap: () {
                      Navigator.pushNamed(context, "/settings");
                    },
                  ),
                  Divider(
                    color: Colors.grey,
                  ),
                  DrawerItem(
                    icon: Icon(Icons.logout_outlined),
                    onTap: () {
                      Navigator.pushNamedAndRemoveUntil(context, "/welcome", (route) => false);
                    },
                    title: "Logout",
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Version 0.7.7",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 10,
              ),
            ),
            SizedBox(height: 5),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: 7,
        itemBuilder: (context, index) {
          return ExplorePostCard(
            username: 'cem_onuk_$index',
            imagePath: 'assets/images/post_$index.jpeg',
          );
        },
      ),
    );
  }
}

class ExplorePostCard extends StatefulWidget {
  final String username;
  final String imagePath;

  const ExplorePostCard({
    Key? key,
    required this.username,
    required this.imagePath,
  }) : super(key: key);

  @override
  _ExplorePostCardState createState() => _ExplorePostCardState();
}

class _ExplorePostCardState extends State<ExplorePostCard> {
  bool isLiked = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: CircleAvatar(
              backgroundImage: AssetImage('assets/images/post_7.jpeg'),
            ),
            title: Text(widget.username),
          ),
          Image.asset(
            widget.imagePath,
            fit: BoxFit.cover,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                icon: Icon(isLiked ? Icons.favorite : Icons.favorite_outline),
                onPressed: () {
                  setState(() {
                    isLiked = !isLiked;
                  });
                },
              ),
              IconButton(
                icon: Icon(Icons.comment),
                onPressed: () {
                  
                },
              ),
              IconButton(
                icon: Icon(Icons.send),
                onPressed: () {
                  
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

