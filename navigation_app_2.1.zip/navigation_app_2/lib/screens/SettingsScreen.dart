import 'package:flutter/material.dart';
import '../widgets/DrawerItem.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "General Settings",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            DrawerItem(
              title: "Account",
              icon: Icon(Icons.account_circle_outlined, size: 25),
              onTap: () {
                
              },
            ),
            DrawerItem(
              title: "Notifications",
              icon: Icon(Icons.notifications_outlined, size: 25),
              onTap: () {
                
              },
            ),
            DrawerItem(
              title: "Privacy",
              icon: Icon(Icons.lock_outline, size: 25),
              onTap: () {
                
              },
            ),
            SizedBox(height: 20),
            Text(
              "App Settings",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            DrawerItem(
              title: "Appearance",
              icon: Icon(Icons.palette_outlined, size: 25),
              onTap: () {
                
              },
            ),
            DrawerItem(
              title: "Language",
              icon: Icon(Icons.language_outlined, size: 25),
              onTap: () {
                
              },
            ),
            DrawerItem(
              title: "Logout",
              icon: Icon(Icons.logout_outlined, size: 25),
              onTap: () {
                
                Navigator.pushNamedAndRemoveUntil(context, "/welcome", (route) => false);
              },
            ),
          ],
        ),
      ),
    );
  }
}
