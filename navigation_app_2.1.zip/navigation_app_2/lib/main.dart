import 'package:flutter/material.dart';
import 'screens/HomeScreen.dart';
import 'screens/SettingsScreen.dart';
import 'screens/aboutusScreen.dart';
import 'screens/exploreScreen.dart';
import 'screens/loginScreen.dart';
import 'screens/registerScreen.dart';
import 'screens/profileScreen.dart';
import 'screens/shopScreen.dart';
import 'screens/WelcomeScreen.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Berke',
      debugShowCheckedModeBanner: false,
      routes: {
        '/home': (context) => HomeScreen(),
        '/login': (context) => loginScreen(),
        '/register': (context) => RegisterScreen(),
        '/profile': (context) => ProfileScreen(),
        '/welcome': (context) => WelcomeScreen(),
        "/shop": (context) => ShopScreen(),
        '/aboutus': (context) => aboutusScreen(),
        "/explore": (context) => ExploreScreen(),
        "/settings": (context) => SettingsScreen(),
      },
      initialRoute: '/welcome',
      theme: ThemeData.light(), // Varsayılan (açık temayı kullanır)
      darkTheme: ThemeData.dark(), // Karanlık tema ekledik
      themeMode: ThemeMode.system, // Sistem temasına uyumlu olarak ayarlandı
      home: HomeScreen(),
    );
  }
}